# Kandang Lab: Eksplorasi Fungsi Kuadrat

Website pembelajaran interaktif tentang fungsi kuadrat. Beranda disediakan pada `index.html` agar cocok dipublikasikan menggunakan GitHub Pages.

## Cara menerbitkan dengan GitHub Pages
1. Masuk ke https://github.com/ dan buat repository baru bernama `kandang-lab-fungsi-kuadrat`.
2. Pilih **Public**.
3. Unggah `index.html` dari folder ini ke direktori utama repository, lalu klik **Commit changes**.
4. Buka **Settings → Pages**.
5. Pada **Build and deployment**, pilih **Deploy from a branch**.
6. Pilih branch `main` dan folder `/(root)`, lalu klik **Save**.
7. Setelah proses deployment selesai, alamat situs biasanya berbentuk:
   `https://USERNAME.github.io/kandang-lab-fungsi-kuadrat/`
   Ganti `USERNAME` dengan nama akun GitHub. Tautan baru aktif setelah publikasi selesai.

Catatan: file yang dipublikasikan ke GitHub Pages bisa diakses publik. Jangan unggah informasi pribadi atau rahasia.
